// =================================================================
// PROJETO CONCURSO AGRINHO 2026 - CATEGORIA PROGRAMAÇÃO (ENSINO MÉDIO)
// TEMA: Agro forte, futuro sustentável: equilíbrio entre produção e meio ambiente
// =================================================================

// Variáveis globais do cenário e elementos interativos
let largura = 800;
let altura = 500;
let tratorX = -100; // Posição inicial do trator fora da tela
let plantas = [];   // Vetor que armazenará as sementes plantadas pelo usuário

function setup() {
  // Cria o canvas e define o tamanho da aplicação
  createCanvas(largura, altura);
  
  // Inicia o cenário com 3 plantas em posições aleatórias para não começar vazio
  for (let i = 0; i < 3; i++) {
    plantas.push({
      x: random(100, largura - 100),
      y: 390, // Linha do solo cultivável
      tamanho: 10
    });
  }
}

function draw() {
  // --- 1. CENÁRIO: CÉU E GRAMADO BASE ---
  background(135, 206, 235); // Céu azul claro
  
  // Solo / Terra cultivável
  fill(139, 69, 19); // Cor marrom terra
  noStroke();
  rect(0, 350, largura, 150);
  
  // Grama superficial
  fill(34, 139, 34); // Verde grama
  rect(0, 350, largura, 15);

  // --- 5. O TRATOR DO AGRINHO ---
  // Chama a função personalizada para desenhar o trator na tela
  desenharTrator(tratorX, 310);
  
  // Movimenta o trator para a direita (corrigido para ponto flutuante)
  tratorX += 1.5; 
  
  // Reinicia a posição do trator ao ultrapassar o limite da tela (corrigido tractorX para tratorX)
  if (tratorX > largura + 150) { 
    tratorX = -150; 
  }

  // --- 6. INTERATIVIDADE: AS PLANTAS CRESCENDO ---
  for (let i = 0; i < plantas.length; i++) { 
    desenharPlanta(plantas[i]);
    
    // Faz a planta crescer gradativamente até o tamanho máximo de 40 (corrigido sintaxe e vírgula)
    if (plantas[i].tamanho < 40) {
      plantas[i].tamanho += 0.2; 
    }
  }

  // --- 7. TEXTO E PLACA ---
  // Placa de madeira (suporte e base)
  fill(160, 82, 45);
  rect(115, 80, 10, 30); // Poste da placa
  rect(30, 30, 180, 50, 5); // Placa principal

  // Texto Agrinho dentro da placa
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(22);
  textStyle(BOLD);
  text("AGRINHO 2026", 120, 55);

  // Instruções de usabilidade para o usuário (Critério importante do edital)
  fill(255); // Texto branco sobre a terra para dar leitura/contraste
  textSize(16);
  textStyle(NORMAL);
  textAlign(CENTER, CENTER);
  text("Clique na tela para plantar e ver a evolução sustentável!", largura / 2, altura - 30); 
} 

// --- FUNÇÃO AUXILIAR: DESENHO DO TRATOR ---
// Desenha um trator estilizado usando formas geométricas básicas do p5.js
function drawTrator(x, y) {
  push();
  translate(x, y);
  
  // Cabine / Corpo do Trator (Verde - Agro Sustentável)
  fill(46, 125, 50); 
  rect(40, 10, 50, 40, 5); // Cabine superior
  rect(20, 35, 80, 25, 4); // Base do trator
  
  // Vidro da cabine
  fill(220, 245, 255);
  rect(65, 15, 20, 15);
  
  // Chaminé de escapamento (Simbólica para o Agro 4.0 moderno)
  fill(80);
  rect(30, 15, 5, 20);
  
  // Rodas (Preto com centro cinza)
  fill(30);
  ellipse(35, 60, 30, 30); // Roda dianteira menor
  ellipse(85, 55, 42, 42); // Roda traseira maior (tração)
  
  fill(150);
  ellipse(35, 60, 10, 10);
  ellipse(85, 55, 12, 12);
  
  pop();
}

// Substitui a chamada interna para usar a função criada
function desenharTrator(x, y) {
  drawTrator(x, y);
}

// --- FUNÇÃO AUXILIAR: DESENHO DA PLANTA ---
// Desenha o broto/planta crescendo baseado no tamanho atual do objeto
function desenharPlanta(planta) {
  push();
  // Caule da planta
  stroke(100, 60, 20);
  strokeWeight(3);
  line(planta.x, planta.y, planta.x, planta.y - planta.tamanho);
  
  // Folhas verdes que surgem conforme cresce
  if (planta.tamanho > 15) {
    noStroke();
    fill(76, 175, 80);
    // Folha esquerda
    ellipse(planta.x - 8, planta.y - planta.tamanho + 5, 12, 8);
    // Folha direita
    ellipse(planta.x + 8, planta.y - planta.tamanho + 8, 12, 8);
  }
  
  // Folha do topo
  if (planta.tamanho > 25) {
    fill(56, 142, 60);
    ellipse(planta.x, planta.y - planta.tamanho, 10, 14);
  }
  pop();
}

// --- INTERATIVIDADE DO USUÁRIO ---
// Adiciona uma nova planta na posição horizontal onde o usuário clicou
function mousePressed() {
  // Limita o plantio apenas se o clique for na região da terra (y > 350) e dentro do canvas
  if (mouseY > 350 && mouseY < altura && mouseX > 0 && mouseX < largura) {
    plantas.push({
      x: mouseX,
      y: 390,
      tamanho: 5 // Começa como um brotinho pequeno
    });
  }
}